
import React, { useState, useEffect } from 'react';
import {
  Layout,
  Mail,
  Lock,
  ShieldCheck,
  Zap,
  Globe,
  Loader2,
  UserPlus,
  LogIn,
  Key,
  ShieldAlert,
  Briefcase,
  ChevronDown,
  CheckCircle2
} from 'lucide-react';
import { UserAccount, UserRole, InspectionReport, Industry, ReportTheme, Severity } from '../types';
import apiClient from '../services/apiClient';
import { useAuth } from '../context/AuthContext';
import { initializeDemoSession } from '../services/demoService';

interface LoginProps {
  onLogin: (user: UserAccount) => void;
  defaultMode?: 'signin' | 'signup';
}

const Login: React.FC<LoginProps> = ({ onLogin, defaultMode = 'signin' }) => {
  const [mode, setMode] = useState<'signin' | 'signup'>(defaultMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [role, setRole] = useState<UserRole>(UserRole.FIELD_OPERATOR);
  const [accessToken, setAccessToken] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isDemoLoading, setIsDemoLoading] = useState(false);
  const [error, setError] = useState('');

  const { login } = useAuth();

  // CRITICAL: Force clear fields on mount to prevent malformed pre-population
  useEffect(() => {
    // Clear any potential browser auto-fill with empty string explicitly
    setEmail('');
    setPassword('');
    // SECURITY: Tokens are stored exclusively in httpOnly cookies (set by backend).
    // Do NOT store or read JWT tokens from localStorage — XSS vulnerability.
    // If legacy localStorage keys exist from an older version, clear them once on mount.
    try {
      localStorage.removeItem('axis_token');
      localStorage.removeItem('axis_refresh_token');
      localStorage.removeItem('axis_user');
    } catch (_) { /* storage may be unavailable in sandboxed contexts */ }
  }, []);
   const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (mode === 'signup' && (!fullName || !companyName || !accessToken || !jobTitle))) {
      setError(mode === 'signup' ? 'All mandatory enterprise fields are required.' : 'Identity credentials required.');
      return;
    }

    // Client-side Admin Check REMOVED.
    // We send the 'adminSecret' (mapped from accessToken field) to the backend.
    // The backend validates it and returns 403 if invalid.

    setIsLoading(true);
    setError('');

    const loginData = { email, password };
    const signupData = {
      email,
      password,
      fullName,
      companyName,
      title: jobTitle,
      role,
      adminSecret: accessToken // In the form we use 'accessToken' field for the passkey input
    };

    const attemptAuth = async () => {
      try {
        console.log('DEBUG: Sending Signup Payload:', signupData);
        const response = await apiClient.post(
          mode === 'signin' ? '/auth/login' : '/auth/register',
          mode === 'signin' ? loginData : signupData
        );

        const { user: userData, token, refreshToken } = response.data.data;

        // Use Context for State Update (it handles localStorage)
        login(userData, token, refreshToken);

        onLogin(userData);
      } catch (err: any) {
        console.error('Auth error:', err);
        // Sanitize error message
        const message = err.response?.data?.error?.message || 'Authentication failed. Please verify credentials.';
        setError(message);
      } finally {
        setIsLoading(false);
      }
    };

    attemptAuth();
  };

  const handleDemoAccess = async () => {
    setIsDemoLoading(true);
    try {
      const demoUser = await initializeDemoSession();
      // Dummy tokens for demo
      login(demoUser, 'DEMO_TOKEN', 'DEMO_REFRESH_TOKEN');
      onLogin(demoUser);
    } catch (error) {
      console.error('Demo initialization failed', error);
      setError('Failed to initialize demo session.');
    } finally {
      setIsDemoLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex overflow-hidden font-sans">
      {/* Visual Side Panel */}
      <div className="hidden lg:flex lg:w-1/2 bg-slate-900 relative p-20 flex-col justify-between overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-blue-600 blur-[120px] rounded-full animate-pulse" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-600 blur-[100px] rounded-full animate-pulse delay-700" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-16 animate-in slide-in-from-top duration-700">
            <div className="bg-blue-600 p-3 rounded-2xl shadow-2xl shadow-blue-500/30">
              <Layout className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white tracking-tighter uppercase leading-none">Axis</h1>
              <p className="text-[10px] text-blue-400 font-black uppercase tracking-[0.3em] mt-2">by CoatzadroneUSA</p>
            </div>
          </div>
          <h2 className="text-6xl font-black text-white leading-[1.05] tracking-tighter max-w-md">
            The Standard in <span className="text-blue-500">Aerial Audit</span> Intelligence.
          </h2>
        </div>
        <div className="relative z-10 space-y-4">
          <div className="flex items-center gap-3 text-white/60 text-[10px] font-black uppercase tracking-widest">
            <ShieldCheck className="w-5 h-5 text-blue-500" /> End-to-End Vaulting
          </div>
          <div className="flex items-center gap-3 text-white/60 text-[10px] font-black uppercase tracking-widest">
            <Zap className="w-5 h-5 text-indigo-500" /> Neural Edge Inference
          </div>
        </div>
      </div>

      {/* Identity Forms */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-slate-50/50 overflow-y-auto">
        <div className="w-full max-w-md space-y-8 py-12 animate-in fade-in zoom-in duration-700">
          <div className="text-center lg:text-left mb-6">
            <h3 className="text-4xl font-black text-slate-900 tracking-tighter uppercase leading-none">
              {mode === 'signin' ? 'Secure Portal' : 'Fleet Registration'}
            </h3>
            <p className="text-slate-500 mt-3 font-medium uppercase text-[10px] tracking-widest opacity-60">
              {mode === 'signin' ? 'Verify your system access credentials.' : 'Initialize your authorized corporate identity profile.'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === 'signup' && (
              <div className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-xl space-y-5 mb-6 animate-in slide-in-from-right-4 duration-500">
                <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
                  <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                    <UserPlus className="w-4 h-4 text-blue-600" />
                  </div>
                  <span className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Enterprise Profile Data</span>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                    <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Jane Doe" className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-sm" />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Company Entity</label>
                    <input type="text" value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="Nexus Grid" className="block w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-sm" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Clearance Tier</label>
                  <div className="relative">
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as UserRole)}
                      className="block w-full appearance-none px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-sm"
                    >
                      {Object.values(UserRole).map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                    <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Designation</label>
                  <div className="relative"><Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <input type="text" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} placeholder="Audit Lead" className="block w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-sm" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">
                    {role === UserRole.ADMIN ? 'Master Admin Passkey' : 'Master Access Token'}
                  </label>
                  <div className="relative">
                    <Key className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${role === UserRole.ADMIN ? 'text-blue-500' : 'text-slate-400'}`} />
                    <input
                      type={role === UserRole.ADMIN ? 'password' : 'text'}
                      value={accessToken}
                      onChange={(e) => setAccessToken(e.target.value)}
                      placeholder={role === UserRole.ADMIN ? '••••••••' : 'SKL-AUTH-V4'}
                      className={`block w-full pl-10 pr-4 py-3 bg-slate-50 border ${role === UserRole.ADMIN ? 'border-blue-200' : 'border-slate-200'} rounded-xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all text-sm`}
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Email Identity</label>
                <div className="relative group"><Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="email" value={email || ''} onChange={(e) => setEmail(e.target.value)} placeholder="operator@axis.ai" className="block w-full pl-10 pr-4 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all" />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Access Passphrase</label>
                <div className="relative group"><Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input type="password" value={password || ''} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="block w-full pl-10 pr-4 py-4 bg-white border border-slate-200 rounded-2xl font-bold text-slate-900 focus:ring-4 focus:ring-blue-500/10 outline-none transition-all" />
                </div>
              </div>
            </div>

            {error && <div className="p-4 bg-red-50 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest border border-red-100 flex items-center gap-3"><ShieldAlert className="w-4 h-4" /> {error}</div>}

            <button
              type="submit"
              disabled={isLoading || isDemoLoading}
              className="w-full bg-slate-900 text-white py-6 rounded-[2.25rem] font-black uppercase tracking-[0.2em] text-sm hover:bg-slate-800 transition-all shadow-2xl flex items-center justify-center gap-4 disabled:opacity-70 active:scale-95 mt-6 border-4 border-slate-900 hover:border-blue-600"
            >
              {isLoading ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : mode === 'signin' ? (
                <>Enter Admin Portal <LogIn className="w-6 h-6" /></>
              ) : (
                <>Confirm Registration & Access <CheckCircle2 className="w-6 h-6" /></>
              )}
            </button>
          </form>

          <div className="text-center pt-2">
            <button onClick={() => { setMode(mode === 'signin' ? 'signup' : 'signin'); setError(''); }} className="text-[10px] font-black text-blue-600 uppercase tracking-[0.3em] hover:text-blue-700 transition-colors">
              {mode === 'signin' ? 'Provision New Corporate Identity' : 'Existing Operator Sign In'}
            </button>
          </div>

          <div className="relative py-6">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200"></div></div>
            <div className="relative flex justify-center text-[9px] uppercase font-black tracking-[0.5em] text-slate-400">
              <span className="bg-slate-50/50 px-4">Evaluation Bridge</span>
            </div>
          </div>
          <button onClick={handleDemoAccess} disabled={isLoading || isDemoLoading} className="w-full flex items-center justify-center gap-4 py-4 border border-slate-200 rounded-2xl bg-white hover:bg-slate-50 transition-all text-[10px] font-black uppercase tracking-widest text-slate-600 shadow-sm disabled:opacity-50 active:scale-95 group">
            {isDemoLoading ? <Loader2 className="w-4 h-4 animate-spin text-indigo-600" /> : <Globe className="w-4 h-4 text-indigo-600 group-hover:rotate-12 transition-transform" />} Launch Evaluation Sandbox
          </button>


        </div>
      </div>
    </div>
  );
};

export default Login;
