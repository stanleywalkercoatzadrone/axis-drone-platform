import React, { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Save, ChevronRight, Building2, Mail, Globe, MapPin } from 'lucide-react';
import OnboardingStepper from './OnboardingStepper';
import apiClient from '../../src/services/apiClient';

const OnboardingStep1: React.FC = () => {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const configId = searchParams.get('configId');

    const [form, setForm] = useState({
        name: '',
        industryKey: 'solar',
        email: '',
        phone: '',
        address: { street: '', city: '', state: '', zip: '' }
    });
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');
        try {
            // 1. Create the Client
            const clientRes = await apiClient.post('/clients', form);
            const client = clientRes.data.data;

            // 2. Attach configId if exists
            if (configId) {
                await apiClient.put(`/onboarding/configs/${configId}`, { clientId: client.id });
                await apiClient.put(`/onboarding/${client.id}/step`, { step: 1, status: 'IN_PROGRESS' });
            }

            // 3. Navigate to Step 2
            navigate(`/clients/new/step-2?clientId=${client.id}&configId=${configId || ''}`);
        } catch (err) {
            console.error('Failed to save Step 1:', err);
            setError('Failed to save. Check your connection and try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="max-w-5xl mx-auto py-12 px-6">
            <OnboardingStepper
                currentStep={1}
                steps={[
                    { id: 1, title: 'Company', description: 'Identity' },
                    { id: 2, title: 'Operations', description: 'Logistics' },
                    { id: 3, title: 'Access', description: 'Permissions' }
                ]}
            />

            <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-2xl backdrop-blur-sm">
                <div className="p-8 border-b border-slate-100 bg-slate-50">
                    <h2 className="text-xl font-bold text-slate-900 flex items-center gap-3">
                        <Building2 className="w-6 h-6 text-blue-600" />
                        Client Identity
                    </h2>
                    <p className="text-slate-700 font-medium mt-1">Basic company and contact information.</p>
                </div>

                <form onSubmit={handleSubmit} className="p-8 space-y-6 bg-white">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Company Name *</label>
                            <input
                                required
                                value={form.name}
                                onChange={e => setForm({ ...form, name: e.target.value })}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                placeholder="Acme Solar Inc."
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Industry</label>
                            <select
                                value={form.industryKey}
                                onChange={e => setForm({ ...form, industryKey: e.target.value })}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                            >
                                <option value="solar">Solar</option>
                                <option value="telecom">Telecom</option>
                                <option value="construction">Construction</option>
                                <option value="insurance">Insurance</option>
                                <option value="utilities">Utilities</option>
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Primary Email *</label>
                            <input
                                type="email"
                                required
                                value={form.email}
                                onChange={e => setForm({ ...form, email: e.target.value })}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                placeholder="contact@acmesolar.com"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Phone Number</label>
                            <input
                                value={form.phone}
                                onChange={e => setForm({ ...form, phone: e.target.value })}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                                placeholder="+1 (555) 000-0000"
                            />
                        </div>
                    </div>

                    <div className="pt-8 flex items-center justify-between gap-4">
                        <button
                            type="button"
                            onClick={() => navigate('/')}
                            className="px-6 py-3 text-slate-400 font-medium hover:text-slate-700 transition-colors text-sm"
                        >
                            ✕ Exit to Dashboard
                        </button>
                        <div className="flex items-center gap-4">
                            {error && <p className="text-sm text-red-500 font-medium">{error}</p>}
                            <button
                                type="button"
                                onClick={() => navigate('/clients/new/start')}
                                className="px-6 py-3 text-slate-600 font-bold hover:text-slate-900 transition-colors"
                            >
                                Back
                            </button>
                            <button
                                type="submit"
                                disabled={isLoading}
                                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 px-8 py-3 text-white font-bold rounded-xl transition-all active:scale-95 shadow-[0_10px_30px_rgba(37,99,235,0.3)] disabled:opacity-50"
                            >
                                {isLoading ? 'Creating...' : (
                                    <>
                                        Save &amp; Continue <ChevronRight className="w-5 h-5" />
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default OnboardingStep1;
