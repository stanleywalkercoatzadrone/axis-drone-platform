import jwt from 'jsonwebtoken';
import { AppError } from './errorHandler.js';
import { getCache, setCache, deleteCache } from '../config/redis.js';
import crypto from 'crypto';
import { resolveEffectivePermissions, can } from '../services/permissionService.js';
import { normalizeRole, isAdmin } from '../utils/roleUtils.js';

// SECURITY: JWT_SECRET must be set via environment variable in production.
// A weak fallback here would allow any attacker to forge tokens.
const JWT_SECRET = (() => {
    const secret = process.env.JWT_SECRET;
    if (!secret && process.env.NODE_ENV === 'production') {
        throw new Error('FATAL: JWT_SECRET environment variable is not set. Cannot start in production without it.');
    }
    if (!secret) {
        console.warn('⚠️  WARNING: JWT_SECRET not set — using insecure dev fallback. Do NOT deploy to production without setting JWT_SECRET.');
    }
    return secret || 'dev-only-insecure-jwt-secret-do-not-use-in-prod';
})();

const JWT_ISS = process.env.JWT_ISS || 'axis-drone-platform';
const JWT_AUD = process.env.JWT_AUD || 'axis-drone-client';

const sha256 = (content) => crypto.createHash('sha256').update(content).digest('hex');

export const protect = async (req, res, next) => {
    try {
        // SECURITY: Prefer HttpOnly cookie (XSS-safe) over Authorization header.
        // Bearer header is kept as fallback for API clients, Postman, and mobile apps.
        let token = req.cookies?.access_token;
        if (!token) {
            const authHeader = req.headers.authorization;
            if (authHeader?.startsWith('Bearer ')) {
                token = authHeader.slice(7);
            }
        }

        if (!token) {
            throw new AppError('Not authorized. No token provided.', 401);
        }

        // Use SHA256 of token for blacklist key to prevent abuse
        const tokenHash = sha256(token);
        const blacklisted = await getCache(`blacklist:${tokenHash}`);
        if (blacklisted) {
            throw new AppError('Token has been revoked', 401);
        }

        // Verify token with strict options
        const decoded = jwt.verify(token, JWT_SECRET, {
            algorithms: ['HS256'],
            issuer: JWT_ISS,
            audience: JWT_AUD,
            clockTolerance: 10 // Handle slight clock drift
        });

        // Check cache for user data
        let user = await getCache(`user:${decoded.id}`);

        // Cache-bust guard: if the cached tenant_id looks like a UUID (legacy format
        // before the slug migration), force a fresh DB fetch so the correct slug is used.
        const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (user && user.tenant_id && UUID_RE.test(user.tenant_id)) {
            await deleteCache(`user:${decoded.id}`);
            user = null;
        }

        if (!user) {
            const { query } = await import('../config/database.js');
            const result = await query(
                'SELECT id, email, full_name, company_name, role, permissions, auth_version, tenant_id FROM users WHERE id = $1',
                [decoded.id]
            );

            if (result.rows.length === 0) {
                throw new AppError('User not found', 401);
            }

            user = result.rows[0];

            // Cache for short duration (5 min) for security-critical data
            await setCache(`user:${decoded.id}`, user, 300);
        }

        // Validate auth_version (Global logout)
        if (user.auth_version !== decoded.auth_version) {
            throw new AppError('Session expired. Please log in again.', 401);
        }

        // Resolve effective permissions (roles and granular keys)
        const effective = await resolveEffectivePermissions(user.id, user.role);

        req.user = {
            id: user.id,
            email: user.email,
            fullName: user.full_name,
            companyName: user.company_name,
            role: user.role,
            effectiveRoles: effective.roles,
            permissions: effective.permissions, // Merged legacy + new permissions
            bindings: effective.bindings,
            authVersion: user.auth_version,
            tenantId: user.tenant_id
        };
        next();
    } catch (error) {
        if (error.name === 'JsonWebTokenError') {
            next(new AppError('Invalid token', 401));
        } else if (error.name === 'TokenExpiredError') {
            next(new AppError('Token expired', 401));
        } else {
            next(error);
        }
    }
};

export const authorize = (...roles) => {
    return (req, res, next) => {
        // Normalize both the user's role and the required roles for comparison
        const userRole = normalizeRole(req.user.role);
        const normalizedRequiredRoles = roles.map(r => normalizeRole(r));

        // Check if user's normalized role matches any required role
        const hasRole = normalizedRequiredRoles.includes(userRole) ||
            req.user.effectiveRoles.some(r => normalizedRequiredRoles.includes(normalizeRole(r)));

        if (!hasRole) {
            throw new AppError(
                `User role '${req.user.role}' is not authorized to access this route`,
                403
            );
        }
        next();
    };
};

export const authorizePerm = (permission) => {
    return (req, res, next) => {
        // Admin always has full access (using normalized role check)
        if (isAdmin(req.user) || req.user.effectiveRoles.includes('internal_admin')) {
            return next();
        }

        if (!req.user.permissions.includes(permission)) {
            throw new AppError(
                `You do not have permission to perform this action (${permission})`,
                403
            );
        }
        next();
    };
};

/**
 * Middleware for scoped permission checks (e.g. checking mission access via mission ID in params)
 */
export const checkScopedPermission = (permission, scopeIdParam = 'id', scopeType = 'mission') => {
    return async (req, res, next) => {
        const scopeId = req.params[scopeIdParam];
        const context = { [scopeType + 'Id']: scopeId };

        const isAllowed = await can(req.user, permission, context);

        if (!isAllowed) {
            throw new AppError(`Not authorized for this ${scopeType} (${permission})`, 403);
        }
        next();
    };
};
