import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import cookieParser from 'cookie-parser';
import { createServer } from 'http';
import './config/env.js';
import { startJobAdvancer } from './services/jobAdvancer.js';

console.log('🔄 Loading App Logic (app.js)...');

// Import routes
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import reportRoutes from './routes/reports.js';
import imageRoutes from './routes/images.js';
import syncRoutes from './routes/sync.js';
import auditRoutes from './routes/audit.js';
import systemRoutes from './routes/system.js';
import personnelRoutes from './routes/personnel.js';
import deploymentRoutes from './routes/deployments.js';
import invoiceRoutes from './routes/invoices.js';
import assetRoutes from './routes/assets.js';
import onboardingRoutes from './routes/onboarding.js';
import workbookRoutes from './routes/workbooks.js';
import workItemRoutes from './routes/workItems.js';
import clientRoutes from './routes/clients.js';
import industryRoutes from './routes/industries.js';
import ingestionRoutes from './routes/ingestion.js';
import candidateRoutes from './routes/candidates.js';
import adminRoutes from './routes/admin.js';
import v1Routes from './routes/v1/index.js';
import { query as dbQuery } from './config/database.js';
import { protect } from './middleware/auth.js';
import flightDataRoutes from './routes/flightData.js';
import forecastRoutes from './routes/forecast.js';
import weatherRoutes from './routes/weather.js';
import pilotSecureRoutes from './routes/pilotSecure.js'; // Pilot secure isolation layer
import pilotUploadRoutes from './routes/pilotUpload.js'; // Phase 6: Pilot data upload pipeline
import clientReportsRoutes from './routes/clientReports.js';
import adminMediaRoutes from './routes/adminMedia.js';   // Admin Media Gallery
import orchestratorRoutes from './routes/orchestrator.js'; // Mission Orchestration Engine
import expenseRoutes from './routes/expenses.js'; // Finance Expense Sheet
import missionGridRoutes from './routes/missionGrid.js';    // Global Mission Grid
import blockProgressRoutes from './routes/blockProgress.js'; // LBD Block Progress Module
import thermalFaultRoutes from './routes/thermalFaults.js';   // Thermal Fault Intelligence
import energyLossRoutes from './routes/energyLoss.js';         // Energy Loss Estimation Engine
import thermalDetectionRoutes from './routes/thermalDetection.js'; // AI Thermal Detection Engine
import missionSessionsRoutes from './routes/missionSessions.js';   // Enterprise Session Tracking
import regionCountryRoutes from './routes/regionCountryRoutes.js';  // Geographic Coverage
import pilotMetricsRoutes from './routes/pilotMetrics.js';          // Pilot Performance Metrics
import missionsRoutes from './routes/missions.js';                   // RBAC Mission Management
import lbdRoutes from './routes/lbd.js';                             // LBD Defect Tracking
import clientPortalRoutes from './routes/clientPortal.js';           // Client Portal Scoped Views
import migrationsRoutes from './routes/migrations.js';                // Emergency DB Migrations
import aiRoutes from './routes/ai.js';                                // AI Bridge Routes
import protocolRoutes from './routes/protocols.js';                   // Operational Protocols SOP library
import tenantRoutes from './routes/tenants.js';                       // SaaS Tenant Registration & Management
import { setSocketIO, recoverStalledJobs } from './services/queue.js';      // Processing Pipeline Queue
import subscriptionInvoiceRoutes from './routes/subscriptionInvoices.js'; // SaaS Client Billing
import pilotNetworkRoutes from './routes/pilotNetwork.js';               // Pilot Network Application (public /join)

// Import middleware
import { errorHandler } from './middleware/errorHandler.js';
import { notFound } from './middleware/notFound.js';
import { standardLimiter, authLimiter, sensitiveLimiter } from './middleware/rateLimiter.js';

import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import { Server } from 'socket.io';

const app = express();
const httpServer = createServer(app);

// Enable trust proxy for Cloud Run/Load Balancers
app.set('trust proxy', 1);

// ── Disable ETags so browsers never serve stale cached API responses ──────────
// This fixes the issue where browsers cache empty responses from broken states
// (e.g. after a DB migration) and keep returning 304 even when data changes.
app.disable('etag');

// Force no-cache on all /api routes so browsers always get fresh data
app.use('/api/', (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});

// Initialize Socket.io
const io = new Server(httpServer, {
    cors: {
        origin: process.env.FRONTEND_URL || "http://localhost:3000",
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Socket.io connection handler
io.on('connection', (socket) => {
    console.log('🔌 Client connected:', socket.id);
    socket.on('join_mission', (missionId) => {
        if (missionId) socket.join(`mission_${missionId}`);
    });
    socket.on('disconnect', () => {
        console.log('🔌 Client disconnected:', socket.id);
    });
});

// Connect Socket.IO to pipeline queue for real-time progress
setSocketIO(io);


// Security middleware
// scriptSrc: unsafe-inline is development-only (Vite HMR requires it).
// Production enforces strict 'self' — inline scripts are blocked.
const isDev = process.env.NODE_ENV !== 'production';
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            scriptSrc: isDev ? ["'self'", "'unsafe-inline'"] : ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            imgSrc: ["'self'", "data:", "https:", "blob:"],
            connectSrc: [
                "'self'",
                process.env.FRONTEND_URL || 'https://axisplatform.app',
                process.env.GCS_BUCKET_NAME ? `https://storage.googleapis.com/${process.env.GCS_BUCKET_NAME}` : '',
                "https://generativelanguage.googleapis.com",
                "https://api.open-meteo.com",
                "https://geocoding-api.open-meteo.com",
                "https://tile.openweathermap.org",
            ].filter(Boolean),
            fontSrc: ["'self'", "data:", "https://fonts.gstatic.com"],
            objectSrc: ["'self'", "blob:"],
            mediaSrc: ["'self'"],
            frameSrc: [
                "'self'",
                "blob:",
                "https://www.openstreetmap.org",     // Weather map iframe
            ]
        }
    },
    crossOriginEmbedderPolicy: false
}));

app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    allowedHeaders: ['Content-Type', 'Authorization'],
    exposedHeaders: ['Set-Cookie']
}));

app.use(compression());
// SECURITY: Use minimal Morgan format — avoid logging full query strings which may contain tokens
app.use(morgan(':method :url :status :res[content-length] - :response-time ms'));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

app.use(cookieParser()); // Parse cookies for HttpOnly JWT support

// Health check endpoint (ALSO in app.js for redundancy)
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        service: 'Axis Backend',
        version: '1.0.0'
    });
});

// Apply rate limiting
app.use('/api/', standardLimiter);

// API v1 Routes
app.use('/api/v1', v1Routes);

// API Routes
app.use('/api/auth', authLimiter, authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/images', imageRoutes);
app.use('/api/sync', syncRoutes);
app.use('/api/audit', auditRoutes);
app.use('/api/system', systemRoutes);
app.use('/api/personnel', personnelRoutes);
// ── PUBLIC: Pilot interest response (no auth — verified by HMAC token in URL) ─
// Must be registered BEFORE the authenticated deploymentRoutes router.
app.get('/api/deployments/:id/pilot-interest', async (req, res) => {
    try {
        const { query: dq } = await import('./config/database.js');
        const { createHmac } = await import('crypto');
        const { sendEmail } = await import('./services/emailService.js');

        const { pilotId, response, token } = req.query;
        if (!pilotId || !response || !token) {
            return res.status(400).send('<h2 style="font-family:sans-serif;padding:40px">Invalid response link.</h2>');
        }

        // Verify HMAC token
        const tokenSecret = process.env.JWT_SECRET || process.env.SESSION_SECRET || 'axis-interest-token-secret';
        const expected = createHmac('sha256', tokenSecret)
            .update(`${req.params.id}:${pilotId}`)
            .digest('hex');
        if (token !== expected) {
            return res.status(403).send('<h2 style="font-family:sans-serif;padding:40px">This link is invalid or has expired.</h2>');
        }

        const isInterested = response === 'yes';

        const [missionRes, pilotRes] = await Promise.all([
            dq(`SELECT d.title, d.location, d.date, s.name AS site_name
                FROM deployments d LEFT JOIN sites s ON s.id = d.site_id
                WHERE d.id = $1`, [req.params.id]),
            dq(`SELECT full_name, email FROM personnel WHERE id = $1`, [pilotId]),
        ]);

        const mission = missionRes.rows[0];
        const pilot   = pilotRes.rows[0];
        if (!mission || !pilot) {
            return res.status(404).send('<h2 style="font-family:sans-serif;padding:40px">Mission or pilot not found.</h2>');
        }

        // Audit log
        await dq(
            `INSERT INTO audit_logs (user_id, action, resource_type, resource_id, metadata)
             VALUES (NULL, $1, 'deployment', $2, $3) ON CONFLICT DO NOTHING`,
            [
                isInterested ? 'PILOT_INTEREST_CONFIRMED' : 'PILOT_INTEREST_DECLINED',
                req.params.id,
                JSON.stringify({ pilotId, pilotName: pilot.full_name, response })
            ]
        ).catch(() => {});

        // Admin notification email
        const adminEmail = process.env.ADMIN_EMAIL || process.env.SMTP_USER;
        if (adminEmail) {
            const label   = isInterested ? 'INTERESTED ✅' : 'NOT AVAILABLE ❌';
            const bgColor = isInterested ? '#064e3b' : '#7f1d1d';
            const accentColor = isInterested ? '#6ee7b7' : '#fca5a5';
            const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"/></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
<div style="max-width:520px;margin:40px auto;padding:0 20px;">
  <div style="background:linear-gradient(135deg,#0f172a,#1e3a5f);border-radius:16px 16px 0 0;padding:24px 28px;">
    <div style="font-size:10px;font-weight:700;color:#64748b;letter-spacing:0.2em;text-transform:uppercase;">Axis Platform — Pilot Response</div>
    <div style="font-size:22px;font-weight:900;color:#38bdf8;margin-top:6px;">Interest Inquiry Update</div>
  </div>
  <div style="background:#fff;padding:28px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 16px 16px;">
    <div style="background:${bgColor};border-radius:10px;padding:16px 20px;margin-bottom:24px;">
      <p style="margin:0 0 4px;font-size:10px;font-weight:700;color:${accentColor};text-transform:uppercase;letter-spacing:0.1em;">Pilot Response</p>
      <p style="margin:0;font-size:20px;font-weight:900;color:#fff;">${label}</p>
    </div>
    <table style="width:100%;border-collapse:collapse;font-size:14px;">
      <tr><td style="padding:8px 0;color:#64748b;font-weight:700;width:80px;">Pilot</td><td style="padding:8px 0;color:#0f172a;font-weight:600;">${pilot.full_name}</td></tr>
      <tr><td style="padding:8px 0;color:#64748b;font-weight:700;">Email</td><td style="padding:8px 0;color:#0f172a;">${pilot.email}</td></tr>
      <tr><td style="padding:8px 0;color:#64748b;font-weight:700;">Mission</td><td style="padding:8px 0;color:#0f172a;">${mission.title}</td></tr>
      ${mission.site_name ? `<tr><td style="padding:8px 0;color:#64748b;font-weight:700;">Site</td><td style="padding:8px 0;color:#0f172a;">${mission.site_name}</td></tr>` : ''}
      ${mission.date     ? `<tr><td style="padding:8px 0;color:#64748b;font-weight:700;">Date</td><td style="padding:8px 0;color:#0f172a;">${mission.date}</td></tr>` : ''}
      ${mission.location ? `<tr><td style="padding:8px 0;color:#64748b;font-weight:700;">Location</td><td style="padding:8px 0;color:#0f172a;">${mission.location}</td></tr>` : ''}
    </table>
    <p style="font-size:12px;color:#94a3b8;margin-top:20px;">Automatically generated by Axis Platform when this pilot responded to your interest inquiry.</p>
  </div>
</div></body></html>`;
            await sendEmail(adminEmail, `Pilot Response: ${pilot.full_name} — ${isInterested ? '✅ Interested' : '❌ Not Available'} — ${mission.title}`, html).catch(e => console.error('[pilot-interest] admin email failed:', e.message));
        }

        // Pilot confirmation page
        const pilotPage = `<!DOCTYPE html><html><head><meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>${isInterested ? 'Interest Confirmed' : 'Response Recorded'} — Axis</title>
<style>*{box-sizing:border-box;margin:0;padding:0}body{background:#0f172a;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;padding:20px}.card{background:#1e293b;border:1px solid #334155;border-radius:20px;padding:40px 36px;max-width:420px;width:100%;text-align:center}.icon{font-size:52px;margin-bottom:16px}.title{font-size:22px;font-weight:800;color:#f8fafc;margin-bottom:10px}.sub{font-size:14px;color:#94a3b8;line-height:1.7}.mission{background:#0f172a;border:1px solid #334155;border-radius:10px;padding:16px;margin-top:24px;text-align:left}.ml{font-size:10px;font-weight:700;color:#475569;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:4px}.mv{font-size:14px;color:#e2e8f0;font-weight:600;margin-bottom:10px}.badge{display:inline-block;padding:6px 16px;border-radius:999px;font-size:12px;font-weight:700;margin-top:24px;${isInterested ? 'background:#064e3b;color:#6ee7b7;' : 'background:#7f1d1d;color:#fca5a5;'}}</style>
</head><body>
<div class="card">
  <div class="icon">${isInterested ? '✅' : '👋'}</div>
  <div class="title">${isInterested ? 'Interest Confirmed!' : 'Response Recorded'}</div>
  <p class="sub">${isInterested
    ? 'Our operations team has been notified and will be in touch soon with the next steps.'
    : 'No problem at all. We appreciate you letting us know and will keep you in mind for future opportunities.'
  }</p>
  <div class="mission">
    <div class="ml">Mission</div><div class="mv">${mission.title}</div>
    ${mission.site_name ? `<div class="ml">Site</div><div class="mv">${mission.site_name}</div>` : ''}
    ${mission.location  ? `<div class="ml">Location</div><div class="mv">${mission.location}</div>` : ''}
  </div>
  <div class="badge">${isInterested ? '✅ Interested' : '❌ Not Available'}</div>
</div>
</body></html>`;

        res.setHeader('Content-Type', 'text/html');
        res.send(pilotPage);
    } catch (e) {
        console.error('[pilot-interest]', e.message);
        res.status(500).send('<h2 style="font-family:sans-serif;padding:40px">Something went wrong. Please contact operations directly.</h2>');
    }
});

app.use('/api/deployments', deploymentRoutes);
app.use('/api/invoices', invoiceRoutes);
app.use('/api/expenses', expenseRoutes);
app.use('/api/assets', assetRoutes);
app.use('/api/onboarding', onboardingRoutes);
app.use('/api/workbooks', workbookRoutes);
app.use('/api/work-items', workItemRoutes);
app.use('/api/clients', clientRoutes);
app.use('/api/industries', industryRoutes);
app.use('/api/ingestion', ingestionRoutes);
app.use('/api/candidates', candidateRoutes);
app.use('/api/admin', adminRoutes); // Axis Intelligence Module (admin-only)
app.use('/api/admin/media', adminMediaRoutes); // Admin Media Gallery
app.use('/api/flight-data', flightDataRoutes); // KML + Flight Params ingest
app.use('/api/forecast', forecastRoutes);       // Mission Forecasting Engine
app.use('/api/weather', weatherRoutes);         // Weather proxy
app.use('/api/pilot/secure', pilotSecureRoutes); // Pilot isolation + secure endpoints
app.use('/api/pilot/upload-jobs', pilotUploadRoutes); // Phase 6: Pilot data upload pipeline
app.use('/api/orchestrator', orchestratorRoutes);    // Mission Orchestration Engine
app.use('/api/mission-grid', missionGridRoutes);     // Global Mission Grid (admin-only)
app.use('/api/blocks', blockProgressRoutes);          // LBD Solar Block Progress
app.use('/api/faults', thermalFaultRoutes);           // Thermal Fault Intelligence
app.use('/api/energy-loss', energyLossRoutes);         // Energy Loss Estimation Engine
app.use('/api/tenants', tenantRoutes);                 // SaaS Tenant Registration & Management
app.use('/api/thermal', thermalDetectionRoutes);        // AI Thermal Detection Engine
app.use('/api/sessions', missionSessionsRoutes);       // Enterprise Mission Sessions
app.use('/api/regions', regionCountryRoutes);           // Geographic Coverage (Regions & Countries)
app.use('/api/pilot-metrics', pilotMetricsRoutes);     // Pilot Performance Metrics
app.use('/api/missions', missionsRoutes);               // RBAC Mission Management
app.use('/api/lbd', lbdRoutes);                         // LBD Defect Tracking
app.use('/api/subscription-invoices', subscriptionInvoiceRoutes); // SaaS Client Billing
app.use('/api/client', clientPortalRoutes);             // Client Portal Scoped Views
app.use('/api/migrations', migrationsRoutes);           // Emergency DB Migrations
app.use('/api/ai', aiRoutes);                           // AI Bridge Routes (generate-text, report-generate, solar-analyze)
app.use('/api/protocols', protocolRoutes);              // Operational Protocols (SOP library)
app.use('/api/pilot', pilotSecureRoutes);               // Pilot routes alias (frontend calls /pilot/missions etc.)
app.use('/api/pilot-network', pilotNetworkRoutes);      // Pilot Network Application (public — no auth required)
app.use('/api/uploads', pilotUploadRoutes);             // Upload jobs alias
app.use('/api/client', clientReportsRoutes);             // Client AI reports

// ── TEMPORARY DEBUG ROUTE — NO AUTH — secret key only ───────────────────────
// Remove after debugging mission visibility for walkerst@me.com
import { query as _dbQuery } from './config/database.js';
app.get('/api/debug/pilot-lookup', async (req, res) => {
    if (req.query.key !== 'axis-debug-2026') return res.status(403).json({ success: false });
    const email = req.query.email;
    if (!email) return res.status(400).json({ success: false, message: 'email required' });
    try {
        const user = await _dbQuery(`SELECT id, email, full_name, role FROM users WHERE LOWER(email) = LOWER($1)`, [email]);
        const pers = await _dbQuery(`SELECT id, full_name, email FROM personnel WHERE LOWER(email) = LOWER($1)`, [email]);
        let persByName = { rows: [] };
        if (user.rows[0]?.full_name) {
            persByName = await _dbQuery(`SELECT id, full_name, email FROM personnel WHERE LOWER(full_name) = LOWER($1)`, [user.rows[0].full_name]);
        }
        const allPers = [...pers.rows, ...persByName.rows].filter((v, i, a) => a.findIndex(x => x.id === v.id) === i);
        const assignments = [];
        for (const p of allPers) {
            const dp = await _dbQuery(`SELECT dp.deployment_id, d.title, d.status, d.mission_status_v2 FROM deployment_personnel dp JOIN deployments d ON d.id=dp.deployment_id WHERE dp.personnel_id=$1`, [p.id]);
            const pwa = await _dbQuery(`SELECT pwa.deployment_id, d.title, d.status, d.mission_status_v2 FROM pilot_work_assignments pwa JOIN deployments d ON d.id=pwa.deployment_id WHERE pwa.personnel_id=$1`, [p.id]);
            assignments.push({ personnelId: p.id, personnelName: p.full_name, deployment_personnel: dp.rows, pilot_work_assignments: pwa.rows });
        }
        res.json({ success: true, user: user.rows[0] || null, personnel: allPers, assignments });
    } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});
// ── END TEMP DEBUG ────────────────────────────────────────────────────────────

// ── /api/documents — global document query (by personnelId) ──────────────────
// Called from: DocumentExplorer.tsx and compliance.ts with ?personnelId=X
app.get('/api/documents', protect, async (req, res) => {
    try {
        const { personnelId } = req.query;
        let result;
        if (personnelId) {
            result = await dbQuery(
                `SELECT id, file_name, file_path, file_url, file_size, mime_type, document_type, created_at, expires_at
                 FROM personnel_documents WHERE personnel_id = $1 ORDER BY created_at DESC`,
                [personnelId]
            );
        } else {
            result = await dbQuery(
                `SELECT pd.id, pd.file_name, pd.file_url, pd.file_size, pd.mime_type, pd.document_type, pd.created_at,
                        p.name as personnel_name, p.id as personnel_id
                 FROM personnel_documents pd
                 LEFT JOIN personnel p ON p.id = pd.personnel_id
                 ORDER BY pd.created_at DESC LIMIT 200`
            );
        }
        res.json({ success: true, data: result.rows });
    } catch (e) {
        console.error('[/api/documents]', e.message);
        res.status(500).json({ success: false, message: e.message });
    }
});


// ── Startup Migrations ─────────────────────────────────────────────────────
// Runs when the server boots. Safe to run multiple times (IF NOT EXISTS).
// ── Start background services ───────────────────────────────────────────────

// Run pipeline DB migration + recover stalled jobs
(async () => {
    try {
        const { query: dbQ } = await import('./config/database.js');
        const { readFileSync } = await import('fs');
        const { fileURLToPath } = await import('url');
        const { dirname, join } = await import('path');
        const __dir = dirname(fileURLToPath(import.meta.url));
        const migSql = readFileSync(join(__dir, 'migrations/027_pipeline_extension.sql'), 'utf8');
        await dbQ(migSql);
        console.log('✅ Startup migration: pipeline_jobs + mission_datasets extension ready');
    } catch (mErr) {
        console.warn('⚠️  Pipeline migration:', mErr.message);
    }
    try {
        await recoverStalledJobs();
        console.log('✅ Pipeline: stalled job recovery complete');
    } catch (rErr) {
        console.warn('⚠️  Pipeline recovery:', rErr.message);
    }
})();

(async () => {
    try {
        // industry_key on deployments
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS industry_key TEXT`);
        const r = await dbQuery(`UPDATE deployments SET industry_key = 'solar' WHERE industry_key IS NULL`);
        if (r.rowCount > 0) console.log(`✅ Startup migration: tagged ${r.rowCount} missions with industry_key='solar'`);

        // flight_parameters table
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS flight_parameters (
                id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                deployment_id      UUID UNIQUE REFERENCES deployments(id) ON DELETE CASCADE,
                flight_altitude_m  NUMERIC,
                flight_speed_ms    NUMERIC,
                overlap_percent    NUMERIC,
                gsd_cm             NUMERIC,
                camera_model       TEXT,
                drone_model        TEXT,
                mission_area_acres NUMERIC,
                waypoint_count     INTEGER,
                kml_raw            TEXT,
                params_raw         JSONB,
                created_at         TIMESTAMPTZ DEFAULT NOW(),
                updated_at         TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        console.log('✅ Startup migration: flight_parameters table ready');

        // ── Vendor & Expenses Ledger ───────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS vendor_expenses (
                id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                vendor_name     TEXT NOT NULL,
                project_name    TEXT NOT NULL,
                inv_number      TEXT,
                inv_date        DATE NOT NULL,
                inv_year        INT,
                inv_month       TEXT,
                inv_status      TEXT NOT NULL DEFAULT 'Unpaid',
                payment_date    DATE,
                payment_year    INT,
                payment_month   TEXT,
                invoice_amount  NUMERIC(12,2) NOT NULL DEFAULT 0,
                stanley_addon   NUMERIC(12,2) NOT NULL DEFAULT 0,
                paid_to_vendor  NUMERIC(12,2) NOT NULL DEFAULT 0,
                paid_to_stanley NUMERIC(12,2) NOT NULL DEFAULT 0,
                notes           TEXT,
                tenant_id       UUID,
                created_at      TIMESTAMPTZ DEFAULT NOW(),
                updated_at      TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_ve_inv_date ON vendor_expenses(inv_date DESC)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_ve_status ON vendor_expenses(inv_status)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_ve_vendor ON vendor_expenses(vendor_name)`);
        // Unique on inv_number so invoice-linked rows can be upserted without duplicates
        await dbQuery(`CREATE UNIQUE INDEX IF NOT EXISTS idx_ve_inv_number ON vendor_expenses(inv_number) WHERE inv_number IS NOT NULL`);
        console.log('\u2705 Startup migration: vendor_expenses table ready');

        // ── One-time backfill: Riverstart IV invoices → vendor_expenses ──────
        try {
            const riverstartRes = await dbQuery(`
                SELECT id, title, site_name, tenant_id
                FROM deployments
                WHERE title ILIKE '%riverstart%'
                ORDER BY created_at DESC
                LIMIT 1
            `);
            if (riverstartRes.rows.length > 0) {
                const mission = riverstartRes.rows[0];
                const invRes = await dbQuery(`
                    SELECT i.id, i.amount, i.status, i.created_at, p.full_name as pilot_name
                    FROM invoices i
                    JOIN personnel p ON i.personnel_id = p.id
                    WHERE i.deployment_id = $1
                `, [mission.id]);

                let backfilled = 0;
                for (const inv of invRes.rows) {
                    const d = new Date(inv.created_at);
                    const yr = d.getFullYear();
                    const mo = d.toLocaleString('en-US', { month: 'long' });
                    const isPaid = inv.status === 'PAID';
                    const result = await dbQuery(`
                        INSERT INTO vendor_expenses
                            (vendor_name, project_name, inv_number, inv_date, inv_year, inv_month,
                             inv_status, invoice_amount, stanley_addon, paid_to_vendor, paid_to_stanley,
                             notes, tenant_id)
                        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,0,$9,0,$10,$11)
                        ON CONFLICT (inv_number) DO NOTHING
                    `, [
                        inv.pilot_name || 'Unknown Pilot',
                        mission.title,
                        inv.id,
                        inv.created_at,
                        yr, mo,
                        isPaid ? 'Paid' : 'Unpaid',
                        inv.amount,
                        isPaid ? inv.amount : 0,
                        `Backfill: ${mission.site_name || mission.title}`,
                        mission.tenant_id || null,
                    ]);
                    if (result.rowCount > 0) backfilled++;
                }
                console.log(`\u2705 Riverstart IV backfill: ${backfilled} invoice(s) added to vendor_expenses (${invRes.rows.length - backfilled} already existed)`);
            }
        } catch (bfErr) {
            console.warn('\u26a0\ufe0f Riverstart IV backfill skipped:', bfErr.message);
        }

        // ── Ensure current_stage column exists on orthomosaic_jobs (used by jobAdvancer) ──
        await dbQuery(`ALTER TABLE orthomosaic_jobs ADD COLUMN IF NOT EXISTS current_stage TEXT`);

        // ── Remove all malformed orthomosaic_outputs rows accumulated by previous bugs ──
        // Raw S3 URLs require Pix4D AWS auth (NoSuchBucket). Pix4D web URLs require login.
        // Only GCS-hosted paths should ever persist in this table.
        const cleaned = await dbQuery(`
            DELETE FROM orthomosaic_outputs
            WHERE gcs_path LIKE '%s3.amazonaws.com%'
               OR gcs_path LIKE '%cloud.pix4d.com%'
               OR gcs_path LIKE 'https://.s3.%'
               OR gcs_path IS NULL
               OR gcs_path = ''
               OR output_type = 'pix4d_viewer'
        `);
        if (cleaned.rowCount > 0) {
            console.log(`[startup-migration] Cleaned ${cleaned.rowCount} malformed orthomosaic_outputs rows`);
        }

        // ── Axis Intelligence tables ──────────────────────────────────────
        await dbQuery(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`);
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS axis_mission_intel (
                id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                mission_id       UUID NOT NULL UNIQUE,
                risk_score       INTEGER,
                priority_level   VARCHAR(20),
                recommended_pilot_count INTEGER,
                weather_concern  VARCHAR(500),
                estimated_completion_days INTEGER,
                financial_exposure DECIMAL(12,2),
                safety_flags     JSONB DEFAULT '[]'::jsonb,
                block_priority_strategy JSONB DEFAULT '{}'::jsonb,
                created_at       TIMESTAMP DEFAULT NOW(),
                updated_at       TIMESTAMP DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_axis_mission_intel_mission_id ON axis_mission_intel(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_axis_mission_intel_risk_score ON axis_mission_intel(risk_score DESC)`);
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS axis_mission_intel_simulations (
                id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
                mission_id  UUID NOT NULL,
                overrides   JSONB DEFAULT '{}'::jsonb,
                results     JSONB DEFAULT '{}'::jsonb,
                created_at  TIMESTAMP DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_axis_intel_sims_mission_id ON axis_mission_intel_simulations(mission_id)`);
        console.log('✅ Startup migration: axis_mission_intel tables ready');

        // ── AI Reports archive table ──────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS ai_reports (
                id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                deployment_id UUID REFERENCES deployments(id) ON DELETE CASCADE,
                industry      TEXT,
                report_type   TEXT,
                report_data   JSONB,
                pdf_url       TEXT,
                generated_by  UUID,
                created_at    TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_ai_reports_deployment_id ON ai_reports(deployment_id)`);
        console.log('✅ Startup migration: ai_reports table ready');

        // ── Pilot Upload Jobs tables ────────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS upload_jobs (
                id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                pilot_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                mission_id      UUID NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
                upload_type     VARCHAR(50)  NOT NULL DEFAULT 'images',
                analysis_type   VARCHAR(100) DEFAULT 'thermal_fault',
                mission_folder  VARCHAR(255),
                lbd_block       VARCHAR(255),
                notes           TEXT,
                status          VARCHAR(30)  NOT NULL DEFAULT 'pending',
                report_url      TEXT,
                created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
                updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
            )
        `);
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS upload_files (
                id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                job_id          UUID NOT NULL REFERENCES upload_jobs(id) ON DELETE CASCADE,
                file_name       VARCHAR(512) NOT NULL,
                file_size       BIGINT       DEFAULT 0,
                file_path       TEXT,
                storage_url     TEXT,
                status          VARCHAR(30)  NOT NULL DEFAULT 'pending',
                ai_result       JSONB,
                pix4d_job_id    VARCHAR(255),
                error_message   TEXT,
                created_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
                updated_at      TIMESTAMPTZ  NOT NULL DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_upload_jobs_pilot_id   ON upload_jobs(pilot_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_upload_jobs_mission_id ON upload_jobs(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_upload_jobs_status     ON upload_jobs(status)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_upload_files_job_id    ON upload_files(job_id)`);
        // Ensure all columns exist even if the table was created before this migration
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS mission_folder  VARCHAR(255)`);
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS lbd_block       VARCHAR(255)`);
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS analysis_type   VARCHAR(100) DEFAULT 'thermal_fault'`);
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS report_url      TEXT`);
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS file_count      INTEGER DEFAULT 0`);
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS error_count     INTEGER DEFAULT 0`);
        await dbQuery(`ALTER TABLE upload_jobs ADD COLUMN IF NOT EXISTS processed_count INTEGER DEFAULT 0`);
        console.log('✅ Startup migration: upload_jobs and upload_files tables ready');


        // ── Mission Forecasting Engine tables ──────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_daily_performance (
                id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id             UUID NOT NULL,
                date                   DATE NOT NULL,
                expected_output        INTEGER,
                actual_output          INTEGER,
                completion_rate        DECIMAL(5,2),
                delay_reason           VARCHAR(500),
                weather_conditions     JSONB DEFAULT '{}'::jsonb,
                irradiance_level       DECIMAL(10,2),
                notes_extracted_factors JSONB DEFAULT '{}'::jsonb,
                created_at             TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(mission_id, date)
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mdp_mission_id ON mission_daily_performance(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mdp_date ON mission_daily_performance(date)`);

        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_forecast_windows (
                id                      UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id              UUID NOT NULL,
                forecast_start_date     DATE NOT NULL,
                forecast_end_date       DATE NOT NULL,
                consecutive_days        INTEGER,
                weather_score           INTEGER,
                irradiance_score        INTEGER,
                predicted_completion_rate DECIMAL(5,2),
                confidence_score        INTEGER,
                recommended             BOOLEAN DEFAULT FALSE,
                created_at              TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mfw_mission_id ON mission_forecast_windows(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mfw_confidence ON mission_forecast_windows(confidence_score DESC)`);
        // Phase 2: Additional forecast performance indexes
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mfw_start_date ON mission_forecast_windows(forecast_start_date)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mfw_recommended ON mission_forecast_windows(recommended) WHERE recommended = TRUE`);
        console.log('✅ Startup migration: mission forecasting tables + indexes ready');

        // Phase 5: system_settings table for scheduler resilience
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS system_settings (
                setting_key        VARCHAR(255) PRIMARY KEY,
                setting_value      TEXT,
                updated_at TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        // If the table was just created, it might not have the id, encrypted, updated_by columns, but existing one does. 
        // The insert needs to match the column names of the existing table.
        try {
            await dbQuery(`INSERT INTO system_settings (setting_key, setting_value) VALUES ('last_forecast_run', NULL) ON CONFLICT (setting_key) DO NOTHING`);
        } catch (e) {
            console.log('[startup-migration] Could not insert last_forecast_run: ', e.message);
        }
        console.log('✅ Startup migration: system_settings table ready');

        // ── Phase 4: Mission coordinates ─────────────────────────────────────
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS latitude DECIMAL(10,7)`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS longitude DECIMAL(10,7)`);
        console.log('✅ Startup migration: deployments lat/lon columns ready');

        // ── Pilots needed count ───────────────────────────────────────────────
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS pilots_needed INTEGER`);
        console.log('✅ Startup migration: deployments.pilots_needed column ready');

        // ── Mission Expenses table ────────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_expenses (
                id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                tenant_id    UUID,
                mission_id   UUID REFERENCES deployments(id) ON DELETE SET NULL,
                category     TEXT NOT NULL DEFAULT 'Other',
                description  TEXT,
                amount       NUMERIC(12,2) NOT NULL DEFAULT 0,
                expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
                vendor       TEXT,
                uploaded_by  UUID,
                file_name    TEXT,
                file_url     TEXT,
                notes        TEXT,
                created_at   TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_me_tenant ON mission_expenses(tenant_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_me_mission ON mission_expenses(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_me_date ON mission_expenses(expense_date DESC)`);
        console.log('✅ Startup migration: mission_expenses table ready');

        // ── Phase 9: Industries table ─────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS industries (
                id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                name                      TEXT NOT NULL UNIQUE,
                default_flight_parameters JSONB DEFAULT '{}'::jsonb,
                default_checklist         JSONB DEFAULT '[]'::jsonb,
                default_report_schema     JSONB DEFAULT '{}'::jsonb,
                created_at                TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`
            INSERT INTO industries (name) VALUES
              ('solar'), ('infrastructure'), ('insurance'), ('agriculture'), ('energy')
            ON CONFLICT (name) DO NOTHING
        `);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS industry_id UUID REFERENCES industries(id)`);
        console.log('✅ Startup migration: industries table + deployments.industry_id ready');

        // ── Phase 10: Sites table ─────────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS sites (
                id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                site_name   TEXT,
                latitude    DECIMAL(10,7),
                longitude   DECIMAL(10,7),
                client_id   UUID,
                industry_id UUID REFERENCES industries(id),
                acreage     DECIMAL(10,2),
                region      TEXT,
                created_at  TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_sites_client_id ON sites(client_id)`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS site_id UUID REFERENCES sites(id)`);
        console.log('✅ Startup migration: sites table + deployments.site_id ready');

        // ── Phase 11: Pilot performance table ────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS pilot_performance (
                id                       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                pilot_id                 UUID NOT NULL,
                missions_completed       INTEGER DEFAULT 0,
                average_blocks_per_day   DECIMAL(10,2),
                weather_adjusted_output  DECIMAL(10,2),
                delay_factor_frequency   JSONB DEFAULT '{}'::jsonb,
                equipment_failure_rate   DECIMAL(5,2),
                report_quality_score     DECIMAL(5,2),
                created_at               TIMESTAMPTZ DEFAULT NOW(),
                updated_at               TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_pilot_performance_pilot_id ON pilot_performance(pilot_id)`);
        console.log('✅ Startup migration: pilot_performance table ready');

        // ── Phase 12: Security events table ──────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS security_events (
                id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                user_id    UUID,
                event_type TEXT NOT NULL,
                resource   TEXT,
                ip_address TEXT,
                metadata   JSONB DEFAULT '{}'::jsonb,
                timestamp  TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_security_events_user_id ON security_events(user_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_security_events_event_type ON security_events(event_type)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_security_events_timestamp ON security_events(timestamp DESC)`);
        console.log('✅ Startup migration: security_events table ready');

        // ── Phase 7: forecast_confidence computed column ───────────────────────
        await dbQuery(`ALTER TABLE mission_forecast_windows ADD COLUMN IF NOT EXISTS forecast_confidence INTEGER`);
        console.log('✅ Startup migration: mission_forecast_windows.forecast_confidence ready');

        // ── Phase 9: pilot_performance reliability_score field ─────────────────
        await dbQuery(`ALTER TABLE pilot_performance ADD COLUMN IF NOT EXISTS reliability_score DECIMAL(5,2)`);
        console.log('✅ Startup migration: pilot_performance.reliability_score ready');

        // ── Phase 12: Mission schedule suggestions (advisory only) ─────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_schedule_suggestions (
                id                     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id             UUID NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
                suggested_start_date   DATE,
                suggested_end_date     DATE,
                recommended_pilot_id   UUID,
                estimated_days         INTEGER,
                confidence_score       INTEGER,
                forecast_window        JSONB DEFAULT '{}'::jsonb,
                status                 TEXT DEFAULT 'pending',
                admin_notes            TEXT,
                created_at             TIMESTAMPTZ DEFAULT NOW(),
                reviewed_at            TIMESTAMPTZ
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mss_mission_id ON mission_schedule_suggestions(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mss_status ON mission_schedule_suggestions(status)`);
        console.log('✅ Startup migration: mission_schedule_suggestions table ready');

        // ── Phase 10: notifications table ──────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS notifications (
                id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                tenant_id   TEXT,
                mission_id  UUID,
                type        TEXT DEFAULT 'FORECAST_ALERT',
                title       TEXT,
                message     TEXT,
                read        BOOLEAN DEFAULT FALSE,
                created_at  TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_notifications_tenant ON notifications(tenant_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_notifications_mission ON notifications(mission_id)`);
        console.log('✅ Startup migration: notifications table ready');

        // ── Phase 12: orchestration_enabled flag on deployments ───────────────
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS orchestration_enabled BOOLEAN DEFAULT TRUE`);
        console.log('✅ Startup migration: deployments.orchestration_enabled ready');

        // ── Phase 1: mission_orchestration table ─────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_orchestration (
                id                         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id                 UUID NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
                recommended_start_date     DATE,
                recommended_end_date       DATE,
                recommended_pilot          UUID REFERENCES users(id),
                recommended_forecast_window UUID,
                predicted_completion_days  INTEGER,
                ai_confidence              INTEGER,
                priority_score             INTEGER,
                status                     TEXT DEFAULT 'suggested',
                manual_override            BOOLEAN DEFAULT FALSE,
                override_reason            TEXT,
                approved_by                UUID,
                created_at                 TIMESTAMPTZ DEFAULT now(),
                updated_at                 TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mission_orch_mission ON mission_orchestration(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mission_orch_priority ON mission_orchestration(priority_score DESC)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mission_orch_status ON mission_orchestration(status)`);
        console.log('✅ Startup migration: mission_orchestration table ready');

        // ── Phase 6: orchestration_override_logs table ───────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS orchestration_override_logs (
                id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id    UUID,
                previous_plan JSONB,
                new_plan      JSONB,
                reason        TEXT,
                changed_by    UUID,
                created_at    TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_ool_mission ON orchestration_override_logs(mission_id)`);
        console.log('✅ Startup migration: orchestration_override_logs table ready');

        // ── Phase 1 (Mission Grid): Spatial geo index on deployments ─────────
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_deployments_geo ON deployments(latitude, longitude)`);
        console.log('✅ Startup migration: deployments geo index ready');

        // ── Phase 2 (Mission Grid): mission_status operational field ─────────
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS mission_status TEXT DEFAULT 'pending'`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_deployments_mission_status ON deployments(mission_status)`);
        console.log('✅ Startup migration: deployments.mission_status ready');

        // ── Phase 1 (LBD): solar_blocks registry ─────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS solar_blocks (
                id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                deployment_id UUID NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
                block_name    TEXT,
                block_number  INTEGER,
                acreage       DECIMAL(10,2),
                latitude      DECIMAL(10,7),
                longitude     DECIMAL(10,7),
                status        TEXT DEFAULT 'pending',
                created_at    TIMESTAMPTZ DEFAULT now(),
                updated_at    TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_blocks_deployment ON solar_blocks(deployment_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_blocks_status ON solar_blocks(status)`);
        console.log('✅ Startup migration: solar_blocks table ready');

        // ── Phase 2 (LBD): block_progress tracking ────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS block_progress (
                id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                block_id          UUID REFERENCES solar_blocks(id) ON DELETE CASCADE,
                pilot_id          UUID REFERENCES users(id),
                mission_id        UUID REFERENCES deployments(id),
                acres_completed   DECIMAL(10,2),
                inspection_type   TEXT,
                flight_hours      DECIMAL(10,2),
                images_collected  INTEGER,
                data_uploaded     BOOLEAN DEFAULT FALSE,
                completed_at      TIMESTAMPTZ,
                created_at        TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_block_progress_block ON block_progress(block_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_block_progress_pilot ON block_progress(pilot_id)`);
        console.log('✅ Startup migration: block_progress table ready');

        // ── Phase 1 (Thermal): thermal_faults table ────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS thermal_faults (
                id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                deployment_id     UUID REFERENCES deployments(id) ON DELETE CASCADE,
                block_id          UUID REFERENCES solar_blocks(id) ON DELETE SET NULL,
                image_id          UUID,
                latitude          DECIMAL(10,7),
                longitude         DECIMAL(10,7),
                temperature_delta DECIMAL(6,2),
                fault_type        TEXT,
                severity          TEXT DEFAULT 'low',
                confidence_score  INTEGER,
                status            TEXT DEFAULT 'open',
                detected_at       TIMESTAMPTZ DEFAULT now(),
                created_at        TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_faults_deployment ON thermal_faults(deployment_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_faults_block ON thermal_faults(block_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_faults_severity ON thermal_faults(severity)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_faults_status ON thermal_faults(status)`);
        console.log('✅ Startup migration: thermal_faults table ready');

        // ── Phase 12 (Thermal): fault_risk_score on solar_blocks ──────────────
        await dbQuery(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS fault_risk_score INTEGER DEFAULT 0`);
        console.log('✅ Startup migration: solar_blocks.fault_risk_score ready');

        // ── Phase 1 (Energy Loss): fault_energy_loss table ────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS fault_energy_loss (
                id                             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                fault_id                       UUID REFERENCES thermal_faults(id) ON DELETE CASCADE,
                deployment_id                  UUID REFERENCES deployments(id) ON DELETE CASCADE,
                block_id                       UUID REFERENCES solar_blocks(id) ON DELETE SET NULL,
                estimated_kw_loss              DECIMAL(10,4),
                estimated_kwh_loss_daily       DECIMAL(10,4),
                estimated_kwh_loss_annual      DECIMAL(10,4),
                estimated_revenue_loss_daily   DECIMAL(10,2),
                estimated_revenue_loss_annual  DECIMAL(10,2),
                manual_override                BOOLEAN DEFAULT FALSE,
                calculated_at                  TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_energy_loss_fault ON fault_energy_loss(fault_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_energy_loss_deployment ON fault_energy_loss(deployment_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_energy_loss_block ON fault_energy_loss(block_id)`);
        console.log('✅ Startup migration: fault_energy_loss table ready');

        // ── Phase 14 (Energy Loss): manual_override column (if table existed before) ──
        await dbQuery(`ALTER TABLE fault_energy_loss ADD COLUMN IF NOT EXISTS manual_override BOOLEAN DEFAULT FALSE`);
        console.log('✅ Startup migration: fault_energy_loss.manual_override ready');

        // ── Phase 1 (Thermal Detection): thermal_images table ──────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS thermal_images (
                id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                deployment_id UUID REFERENCES deployments(id) ON DELETE CASCADE,
                pilot_id      UUID REFERENCES users(id),
                file_url      TEXT,
                latitude      DECIMAL(10,7),
                longitude     DECIMAL(10,7),
                capture_time  TIMESTAMPTZ,
                image_width   INTEGER,
                image_height  INTEGER,
                sensor_model  TEXT,
                created_at    TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_thermal_images_deployment ON thermal_images(deployment_id)`);
        console.log('✅ Startup migration: thermal_images table ready');

        // ── Phase 13 (Thermal Detection): ai_detected + review_status columns ──
        await dbQuery(`ALTER TABLE thermal_faults ADD COLUMN IF NOT EXISTS ai_detected BOOLEAN DEFAULT TRUE`);
        await dbQuery(`ALTER TABLE thermal_faults ADD COLUMN IF NOT EXISTS review_status TEXT DEFAULT 'pending'`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_faults_review_status ON thermal_faults(review_status)`);
        console.log('✅ Startup migration: thermal_faults AI tracking columns ready');

        // ── City/State on deployments (for geocoding + forecast) ──────────────
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS city VARCHAR(100)`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS state VARCHAR(100)`);
        // New: Technical Metadata for AI Analysis
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS installed_power_kw NUMERIC`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS panel_count INTEGER`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS panel_model TEXT`);
        // Backfill from existing location text (e.g. "Houston, TX")
        await dbQuery(`
            UPDATE deployments
            SET city  = TRIM(SPLIT_PART(location, ',', 1)),
                state = TRIM(SPLIT_PART(location, ',', 2))
            WHERE location IS NOT NULL AND location LIKE '%,%' AND city IS NULL
        `);
        console.log('✅ Startup migration: deployments city/state columns ready');


        // ── Phase: Enterprise Session Tracking ───────────────────────────────
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS mission_status_v2 TEXT DEFAULT 'assigned'`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS completion_percent INT DEFAULT 0`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS billing_status TEXT DEFAULT 'not_billable'`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS allow_partial_invoice BOOLEAN DEFAULT true`);
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS total_sessions INT DEFAULT 0`);

        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_work_sessions (
                id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id       UUID REFERENCES deployments(id) ON DELETE CASCADE,
                pilot_id         UUID,
                session_number   INT,
                session_date     DATE,
                start_time       TIMESTAMPTZ DEFAULT now(),
                end_time         TIMESTAMPTZ,
                completion_percent INT DEFAULT 0,
                status           TEXT DEFAULT 'active',
                reason_closed    TEXT,
                weather_stop     BOOLEAN DEFAULT false,
                billable         BOOLEAN DEFAULT true,
                invoice_id       UUID,
                payment_status   TEXT DEFAULT 'pending',
                notes            TEXT,
                created_at       TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_sessions_mission_id ON mission_work_sessions(mission_id)`);
        console.log('✅ Startup migration: mission_work_sessions table ready');

        // ── Backfill NULL mission_status_v2 to 'assigned' for all existing missions ──
        const backfillRes = await dbQuery(`UPDATE deployments SET mission_status_v2 = 'assigned' WHERE mission_status_v2 IS NULL`);
        if (backfillRes.rowCount > 0) console.log(`✅ Backfilled ${backfillRes.rowCount} missions to mission_status_v2='assigned'`);

        // ── Phase 5: mission_timeline table ──────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_timeline (
                id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id  UUID REFERENCES deployments(id) ON DELETE CASCADE,
                event_type  TEXT NOT NULL,
                description TEXT,
                session_id  UUID,
                created_by  UUID,
                created_at  TIMESTAMP DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_timeline_mission ON mission_timeline(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_timeline_created ON mission_timeline(created_at DESC)`);
        console.log('✅ Startup migration: mission_timeline table ready');

        // ── Phase 8: pilot_metrics table ─────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS pilot_metrics (
                id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                pilot_id                  UUID UNIQUE NOT NULL,
                missions_completed        INT DEFAULT 0,
                sessions_completed        INT DEFAULT 0,
                weather_interruptions     INT DEFAULT 0,
                avg_completion_speed      FLOAT DEFAULT 0,
                thermal_faults_detected   INT DEFAULT 0,
                rating                    FLOAT DEFAULT 5.0,
                pilot_score               FLOAT DEFAULT 0,
                last_updated              TIMESTAMP DEFAULT now(),
                created_at                TIMESTAMP DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_pilot_metrics_pilot ON pilot_metrics(pilot_id)`);
        console.log('✅ Startup migration: pilot_metrics table ready');

        // ── Geographic Coverage: Regions & Countries seed ─────────────────
        await dbQuery(`CREATE TABLE IF NOT EXISTS regions (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name VARCHAR(100) NOT NULL UNIQUE, created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW())`);
        await dbQuery(`CREATE TABLE IF NOT EXISTS countries (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), region_id UUID REFERENCES regions(id) ON DELETE CASCADE, name VARCHAR(100) NOT NULL, iso_code VARCHAR(10) NOT NULL UNIQUE, currency VARCHAR(10) DEFAULT 'USD', units_of_measurement VARCHAR(20) DEFAULT 'imperial', status VARCHAR(20) DEFAULT 'ENABLED', created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW())`);
        await dbQuery(`INSERT INTO regions (name) VALUES ('North America'),('Central America'),('South America'),('Caribbean') ON CONFLICT (name) DO NOTHING`);
        const regRows = (await dbQuery('SELECT id, name FROM regions')).rows;
        const rm = Object.fromEntries(regRows.map(r => [r.name, r.id]));
        const ctries = [
            ['North America', 'United States', 'US', 'USD', 'imperial'], ['North America', 'Canada', 'CA', 'CAD', 'metric'], ['North America', 'Mexico', 'MX', 'MXN', 'metric'],
            ['Central America', 'Guatemala', 'GT', 'GTQ', 'metric'], ['Central America', 'Belize', 'BZ', 'BZD', 'metric'], ['Central America', 'Honduras', 'HN', 'HNL', 'metric'],
            ['Central America', 'El Salvador', 'SV', 'USD', 'metric'], ['Central America', 'Nicaragua', 'NI', 'NIO', 'metric'], ['Central America', 'Costa Rica', 'CR', 'CRC', 'metric'], ['Central America', 'Panama', 'PA', 'PAB', 'metric'],
            ['South America', 'Colombia', 'CO', 'COP', 'metric'], ['South America', 'Venezuela', 'VE', 'VES', 'metric'], ['South America', 'Brazil', 'BR', 'BRL', 'metric'],
            ['South America', 'Peru', 'PE', 'PEN', 'metric'], ['South America', 'Ecuador', 'EC', 'USD', 'metric'], ['South America', 'Bolivia', 'BO', 'BOB', 'metric'],
            ['South America', 'Chile', 'CL', 'CLP', 'metric'], ['South America', 'Argentina', 'AR', 'ARS', 'metric'], ['South America', 'Paraguay', 'PY', 'PYG', 'metric'], ['South America', 'Uruguay', 'UY', 'UYU', 'metric'],
            ['Caribbean', 'Cuba', 'CU', 'CUP', 'metric'], ['Caribbean', 'Dominican Republic', 'DO', 'DOP', 'metric'], ['Caribbean', 'Puerto Rico', 'PR', 'USD', 'imperial']
        ];
        
        // Disable existing countries that are outside of Latin America
        const allowedIsoCodes = ctries.map(c => c[2]);
        await dbQuery(`UPDATE countries SET status = 'DISABLED' WHERE iso_code != ALL($1)`, [allowedIsoCodes]);

        for (const [region, name, iso, currency, units] of ctries) {
            const rid = rm[region]; if (!rid) continue;
            await dbQuery(`INSERT INTO countries (region_id,name,iso_code,currency,units_of_measurement,status) VALUES ($1,$2,$3,$4,$5,'ENABLED') ON CONFLICT (iso_code) DO UPDATE SET currency = EXCLUDED.currency, units_of_measurement = EXCLUDED.units_of_measurement, region_id = EXCLUDED.region_id`, [rid, name, iso, currency, units]);
        }
        console.log('✅ Startup migration: regions & countries seeded (Latin America only, preserving admin statuses)');

        // ── Country FK on deployments (must come after countries table exists) ──
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS country_id UUID REFERENCES countries(id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_deployments_country_id ON deployments(country_id)`);
        // Backfill: assign United States to ALL missions that have no country set yet
        // (All existing missions in the platform are US-based)
        const bfUS = await dbQuery(`
            UPDATE deployments d SET country_id = c.id
            FROM countries c
            WHERE c.iso_code = 'US' AND d.country_id IS NULL
        `);
        if (bfUS.rowCount > 0) console.log('✅ Startup migration: backfilled ' + bfUS.rowCount + ' missions with US country_id');
        console.log('✅ Startup migration: deployments.country_id ready');


        // ── Operational Protocols ─────────────────────────────────────────────
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS protocols (
                id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                tenant_id    TEXT,
                title        TEXT NOT NULL,
                description  TEXT,
                category     TEXT NOT NULL CHECK (category IN ('pre_flight','mission','post_flight','emergency','general')),
                mission_type TEXT DEFAULT 'all',
                steps        JSONB NOT NULL DEFAULT '[]',
                version      TEXT DEFAULT '1.0',
                is_active    BOOLEAN DEFAULT TRUE,
                is_required  BOOLEAN DEFAULT FALSE,
                created_by   UUID REFERENCES users(id) ON DELETE SET NULL,
                created_at   TIMESTAMPTZ DEFAULT NOW(),
                updated_at   TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_protocols (
                id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                mission_id  UUID NOT NULL REFERENCES deployments(id) ON DELETE CASCADE,
                protocol_id UUID NOT NULL REFERENCES protocols(id) ON DELETE CASCADE,
                assigned_by UUID REFERENCES users(id) ON DELETE SET NULL,
                assigned_at TIMESTAMPTZ DEFAULT NOW(),
                UNIQUE(mission_id, protocol_id)
            )
        `);
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS protocol_acknowledgments (
                id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                protocol_id     UUID NOT NULL REFERENCES protocols(id) ON DELETE CASCADE,
                mission_id      UUID REFERENCES deployments(id) ON DELETE CASCADE,
                pilot_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                pilot_name      TEXT,
                step_responses  JSONB DEFAULT '{}',
                acknowledged_at TIMESTAMPTZ DEFAULT NOW(),
                signature       TEXT,
                UNIQUE(protocol_id, mission_id, pilot_id)
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_protocols_category     ON protocols(category)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_mission_protocols_m    ON mission_protocols(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_proto_acks_pilot       ON protocol_acknowledgments(pilot_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_proto_acks_mission     ON protocol_acknowledgments(mission_id)`);
        console.log('✅ Startup migration: operational protocols tables ready');

    } catch (e) {
        console.warn('[startup-migration] warning:', e.message);
    }
})();

// ── Isolated Country Backfill ─────────────────────────────────────────────────
// Runs independently so it always executes regardless of other migration errors.
// Ensures all existing unassigned missions are tagged with United States country_id on every server start.
(async () => {
    try {
        // Ensure country_id column exists (safe if already present)
        await dbQuery(`ALTER TABLE deployments ADD COLUMN IF NOT EXISTS country_id UUID`);
        // Tag all unassigned missions as United States
        const result = await dbQuery(`
            UPDATE deployments d
            SET country_id = c.id
            FROM countries c
            WHERE c.iso_code = 'US'
              AND d.country_id IS NULL
        `);
        if (result.rowCount > 0) console.log('[country-backfill] Tagged', result.rowCount, 'missions as United States');
    } catch (e) {
        console.warn('[country-backfill] skipped:', e.message);
    }
})();

// ── Personnel Country FK Migration ───────────────────────────────────────────
(async () => {
    try {
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS country_id UUID REFERENCES countries(id) ON DELETE SET NULL`);
        console.log('[personnel-country] country_id column ready');
    } catch (e) {
        console.warn('[personnel-country] migration skipped:', e.message);
    }
})();

// ── Pilot Network Applications Table ─────────────────────────────────────────
(async () => {
    try {
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS pilot_network_applications (
                id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                full_name           TEXT NOT NULL,
                email               TEXT NOT NULL,
                phone               TEXT,
                country             TEXT,
                city                TEXT,
                years_exp           INTEGER DEFAULT 0,
                certifications      TEXT[],
                specializations     TEXT[],
                drone_equipment     TEXT,
                bio                 TEXT,
                portfolio_url       TEXT,
                status              TEXT NOT NULL DEFAULT 'pending',
                admin_notes         TEXT,
                reviewed_by         UUID REFERENCES users(id),
                reviewed_at         TIMESTAMPTZ,
                terrestrial_thermal BOOLEAN DEFAULT FALSE,
                created_at          TIMESTAMPTZ DEFAULT NOW(),
                updated_at          TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        // Idempotent columns for existing tables
        await dbQuery(`ALTER TABLE pilot_network_applications ADD COLUMN IF NOT EXISTS terrestrial_thermal BOOLEAN DEFAULT FALSE`);
        // Add profile columns to personnel that may not exist yet
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS bio TEXT`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS city TEXT`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS years_exp INTEGER DEFAULT 0`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS certifications TEXT[]`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS specializations TEXT[]`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS drone_equipment TEXT`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS portfolio_url TEXT`);
        await dbQuery(`ALTER TABLE personnel ADD COLUMN IF NOT EXISTS source TEXT`);
        console.log('✅ Startup migration: pilot_network_applications table ready');
    } catch (e) {
        console.warn('[pilot-network-migration] skipped:', e.message);
    }
})();

// ── LBD Units Migration ───────────────────────────────────────────────────────
// Phase LBD-2: Extends solar_blocks with LBD-level tracking + creates lbd_units
(async () => {
    try {
        // Extend solar_blocks with LBD fields (additive, safe)
        await dbQuery(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS total_lbds INT DEFAULT 0`);
        await dbQuery(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS assigned_to UUID REFERENCES users(id) ON DELETE SET NULL`);
        console.log('[lbd-migration] solar_blocks extended with total_lbds, assigned_to');

        // Create lbd_units table — atomic per-LBD tracking
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS lbd_units (
                id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                block_id     UUID NOT NULL REFERENCES solar_blocks(id) ON DELETE CASCADE,
                lbd_code     TEXT NOT NULL,
                lbd_number   INT  NOT NULL,
                status       TEXT NOT NULL DEFAULT 'pending'
                                 CHECK (status IN ('pending','completed','issue')),
                uploaded_by  UUID REFERENCES users(id) ON DELETE SET NULL,
                uploaded_at  TIMESTAMPTZ,
                notes        TEXT,
                thermal_flag TEXT DEFAULT 'normal'
                                 CHECK (thermal_flag IN ('normal','hotspot','critical')),
                file_urls    JSONB DEFAULT '[]',
                created_at   TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_lbd_units_block  ON lbd_units(block_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_lbd_units_status ON lbd_units(status)`);
        await dbQuery(`CREATE UNIQUE INDEX IF NOT EXISTS idx_lbd_units_code ON lbd_units(block_id, lbd_code)`);
        console.log('[lbd-migration] lbd_units table ready');
    } catch (e) {
        console.warn('[lbd-migration] skipped:', e.message);
    }
})();

// ── GUARANTEED: block_progress table ─────────────────────────────────────────
// Isolated so failures in the main startup block never skip this.
(async () => {
    try {
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS block_progress (
                id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                block_id          UUID REFERENCES solar_blocks(id) ON DELETE CASCADE,
                pilot_id          UUID REFERENCES users(id) ON DELETE SET NULL,
                mission_id        UUID REFERENCES deployments(id) ON DELETE SET NULL,
                acres_completed   DECIMAL(10,2),
                inspection_type   TEXT,
                flight_hours      DECIMAL(10,2),
                images_collected  INTEGER,
                data_uploaded     BOOLEAN DEFAULT FALSE,
                completed_at      TIMESTAMPTZ,
                created_at        TIMESTAMPTZ DEFAULT now()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_block_progress_block ON block_progress(block_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_block_progress_pilot ON block_progress(pilot_id)`);
        console.log('✅ Startup: block_progress table ready');
    } catch (e) {
        console.warn('⚠️  Startup: block_progress migration skipped:', e.message);
    }
})();

// ── Solar Blocks Schema Bridge ────────────────────────────────────────────────
// The original migration created solar_blocks with mission_id (not deployment_id).
// The blockProgress.js routes expect deployment_id. This IIFE adds the missing
// columns and backfills deployment_id from mission_id — safe, additive, idempotent.
// Each statement runs independently so one failure never blocks the critical columns.
(async () => {
    const safeAlter = async (sql, label) => {
        try { await dbQuery(sql); console.log(`[solar-blocks-bridge] ✓ ${label}`); }
        catch (e) { console.warn(`[solar-blocks-bridge] ✗ ${label}:`, e.message); }
    };

    // Ensure both id-column aliases exist (plain UUID — no FK to avoid orphan failures)
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS deployment_id UUID`, 'deployment_id column');
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS mission_id    UUID`, 'mission_id column');

    // Cross-backfill: deployment_id ← mission_id, and mission_id ← deployment_id
    try {
        const r1 = await dbQuery(`UPDATE solar_blocks SET deployment_id = mission_id WHERE deployment_id IS NULL AND mission_id IS NOT NULL`);
        if (r1.rowCount > 0) console.log(`[solar-blocks-bridge] Backfilled deployment_id on ${r1.rowCount} rows`);
        const r2 = await dbQuery(`UPDATE solar_blocks SET mission_id = deployment_id WHERE mission_id IS NULL AND deployment_id IS NOT NULL`);
        if (r2.rowCount > 0) console.log(`[solar-blocks-bridge] Backfilled mission_id on ${r2.rowCount} rows`);
    } catch (e) { console.warn('[solar-blocks-bridge] backfill skipped:', e.message); }

    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS block_number INT`, 'block_number');
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS acreage DECIMAL(10,2)`, 'acreage');
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS latitude DECIMAL(10,7)`, 'latitude');
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS longitude DECIMAL(10,7)`, 'longitude');
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS total_lbds INT DEFAULT 0`, 'total_lbds');
    await safeAlter(`ALTER TABLE solar_blocks ADD COLUMN IF NOT EXISTS assigned_to UUID`, 'assigned_to');
    await safeAlter(`CREATE INDEX IF NOT EXISTS idx_blocks_deployment ON solar_blocks(deployment_id)`, 'idx_deployment');
    await safeAlter(`CREATE INDEX IF NOT EXISTS idx_blocks_mission    ON solar_blocks(mission_id)`,    'idx_mission');
    await safeAlter(`CREATE INDEX IF NOT EXISTS idx_blocks_status     ON solar_blocks(status)`,        'idx_status');
    console.log('[solar-blocks-bridge] done');
})();

import('./workers/thermalProcessingWorker.js')
    .then(({ startThermalWorker }) => startThermalWorker())
    .catch(err => console.warn('[startup] Thermal worker failed to start:', err.message));


// Error handling for API routes
app.use('/api/*', notFound);
app.use(errorHandler);


// Serve uploaded files (onboarding templates, documents, etc.)
const uploadsPath = path.join(__dirname, '../uploads');
app.use('/uploads', express.static(uploadsPath, {
    setHeaders: (res, path) => {
        if (path.toLowerCase().endsWith('.pdf')) {
            // Force download on mobile/desktop
            res.setHeader('Content-Disposition', 'attachment');
        }
    }
}));

// Serve static files with proper caching headers
const distPath = path.join(__dirname, '../dist');

// ── Root redirect → promo landing page ──────────────────────────────────────
// Visitors to the platform URL see the marketing page first.
// The React app is accessible at /login and all internal routes.
app.get('/', (req, res) => {
    res.redirect(302, 'https://storage.googleapis.com/axis-coatzadrone-landing/index.html');
});

// Cache hashed assets (JS/CSS with unique names) for 1 year
app.use('/assets', express.static(path.join(distPath, 'assets'), {
    maxAge: '1y',
    immutable: true
}));

// Never cache index.html — forces browser to re-fetch after deploy
app.use(express.static(distPath, {
    index: 'index.html',
    setHeaders: (res, filePath) => {
        if (filePath.endsWith('index.html')) {
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
        }
    }
}));

// ── /join — Pilot Network enrollment (SEO meta injected server-side) ─────────
// Reads index.html and injects pilot-specific meta tags before sending.
// This way: crawlers see the correct description/OG tags, and the React app
// still loads from the correct compiled assets (not broken join.html refs).
app.get('/join', async (req, res) => {
    try {
        const { readFileSync } = await import('fs');
        let html = readFileSync(path.join(distPath, 'index.html'), 'utf8');

        const pilotMeta = `
  <title>Join the Axis Pilot Network | Pilot Enrollment &amp; Signup</title>
  <meta name="description" content="Pilot Enrollment — Apply to join the Axis Pilot Network and get matched with enterprise drone inspection missions near you.">
  <meta property="og:title" content="Join the Axis Pilot Network | Pilot Enrollment">
  <meta property="og:description" content="Apply to fly enterprise drone inspection missions for solar, infrastructure, agriculture and more clients worldwide.">
  <meta property="og:url" content="https://axisplatform.app/join">
  <meta property="og:type" content="website">
  <meta name="twitter:card" content="summary">
  <meta name="twitter:title" content="Join the Axis Pilot Network">
  <meta name="twitter:description" content="Pilot Enrollment — Apply now and get matched with enterprise drone missions near you.">
  <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🛸</text></svg>">`;

        // Replace existing title + inject pilot meta right after <head>
        html = html.replace(/<title>.*?<\/title>/, '');
        html = html.replace('<head>', `<head>${pilotMeta}`);

        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Content-Type', 'text/html');
        res.send(html);
    } catch (err) {
        // Fallback: just serve index.html normally
        res.sendFile(path.join(distPath, 'index.html'));
    }
});

// SPA fallback
app.get('*', (req, res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.sendFile(path.join(distPath, 'index.html'));
});

// Export httpServer and io
export { httpServer, app, io };

// ── Background services ───────────────────────────────────────────────────────
// jobAdvancer: advances processing jobs server-side every 15s (survives restarts)
startJobAdvancer(15_000);

console.log('✅ App Logic Loaded');

// ── GUARANTEED: mission_expenses table — runs independently of all other startup migrations ──
// Isolated IIFE so failures in the big startup block above can never skip this.
(async () => {
    try {
        await dbQuery(`
            CREATE TABLE IF NOT EXISTS mission_expenses (
                id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                tenant_id    UUID,
                mission_id   UUID REFERENCES deployments(id) ON DELETE SET NULL,
                category     TEXT NOT NULL DEFAULT 'Other',
                description  TEXT,
                amount       NUMERIC(12,2) NOT NULL DEFAULT 0,
                expense_date DATE NOT NULL DEFAULT CURRENT_DATE,
                vendor       TEXT,
                uploaded_by  UUID,
                file_name    TEXT,
                file_url     TEXT,
                notes        TEXT,
                created_at   TIMESTAMPTZ DEFAULT NOW()
            )
        `);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_me_tenant  ON mission_expenses(tenant_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_me_mission ON mission_expenses(mission_id)`);
        await dbQuery(`CREATE INDEX IF NOT EXISTS idx_me_date    ON mission_expenses(expense_date DESC)`);
        // Add status + updated_at columns if table was created before this migration
        await dbQuery(`ALTER TABLE mission_expenses ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'pending'`);
        await dbQuery(`ALTER TABLE mission_expenses ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW()`);
        console.log('✅ Startup: mission_expenses table ready');
    } catch (e) {
        console.warn('⚠️  Startup: mission_expenses migration skipped:', e.message);
    }
})();
